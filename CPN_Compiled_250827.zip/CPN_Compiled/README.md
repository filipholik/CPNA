# COCOON Programmable Node - University of Glasgow

## Description
An eBPF-based programmable dataplane with SDN architecture for Smart Grid protection.

## Version
250827

