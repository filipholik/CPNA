# COCOON Programmable Node - University of Glasgow

## Description
An eBPF-based programmable dataplane with SDN architecture for Smart Grid protection.

## Instructions
1. Right click in the folder, Open terminal here 
2. Start COMML: ./start_comml.sh 
3. Open a new tab: ctrl+shift+t 
4. In the new tab, start IOL: ./start_iol.sh
5. Open a new tab: ctrl+shift+t 
6. In the new tab, test APIs: ./northbound_test.sh

## Version
250916

